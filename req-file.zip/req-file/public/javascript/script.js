const socket = io();

//  check if geolocation is supported

if (navigator.geolocation) {

    // Request the user's current position
  navigator.geolocation.getCurrentPosition((position) => {
    const { latitude, longitude } = position.coords;
    // Emit the location to the server
    socket.emit("send-location", { latitude, longitude });
  }
  , (error) => {
    console.error("Error getting location:", error);
  }
,
{
    // Options for geolocation
    enableHighAccuracy: true,
    timeout: 5000,
    maximumAge: 0
  });       
}

const map = L.map('map').setView([0, 0], 15);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: 'Samir Shaikh <22amtics312@gmail.com>'
}).addTo(map);



// Object to store user markers by their ID
const markers = {};

// Listen for incoming location data from the server
socket.on('receive-location', (data) => {
    const { id, latitude, longitude } = data;
    // Center the map on the new coordinates
    map.setView([latitude, longitude], 15);

// Check if a marker for this ID already exists
    if (markers[id]) {
        // Update the existing marker's position
        markers[id].setLatLng([latitude, longitude]);
    } else {
        // Create a new marker and add it to the map
        const marker = L.marker([latitude, longitude]).addTo(map);
        markers[id] = marker; // Store it in the markers object
    }

})


// Listen for marker removal when a user disconnects
socket.on('remove-marker', (data) => {
    const { id } = data;
    if (markers[id]) {
        map.removeLayer(markers[id]);
        delete markers[id];
    }
});


socket.on('disconnect', () => {
    // Remove the marker for this user
    if (markers[socket.id]) {
        map.removeLayer(markers[socket.id]);
        delete markers[socket.id];
    }
});